create function get_receipts_price_over(p_price integer)
    returns TABLE(receipt_id integer, cassette_id integer, video_id integer, service_id integer, receipt_date date, receipt_price integer)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT
            R.ReceiptID,
            R.CassetteID,
            R.VideoID,
            R.ServiceID,
            R.Date,
            R.Price
        FROM Receipt R
        WHERE R.Price > p_price;
END;
$$;

alter function get_receipts_price_over(integer) owner to postgres;

