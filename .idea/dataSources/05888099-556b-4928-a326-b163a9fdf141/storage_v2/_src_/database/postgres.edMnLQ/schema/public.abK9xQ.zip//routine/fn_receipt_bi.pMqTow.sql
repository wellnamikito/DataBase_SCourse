create function fn_receipt_bi() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.ReceiptID IS NULL THEN
        NEW.ReceiptID := nextval('seq_receipt');
    END IF;

    RETURN NEW;
END;
$$;

alter function fn_receipt_bi() owner to postgres;

