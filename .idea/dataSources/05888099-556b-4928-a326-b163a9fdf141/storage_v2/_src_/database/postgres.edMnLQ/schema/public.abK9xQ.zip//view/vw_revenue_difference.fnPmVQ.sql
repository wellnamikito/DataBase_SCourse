create view vw_revenue_difference(revenuedifference) as
SELECT max(totalrevenue) - min(totalrevenue) AS revenuedifference
FROM (SELECT sum(r.price) AS totalrevenue
      FROM receipt r
      GROUP BY r.videoid) t;

alter table vw_revenue_difference
    owner to postgres;

