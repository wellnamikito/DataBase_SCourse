create function fn_districts_bi() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.DistrictID IS NULL THEN
        NEW.DistrictID := nextval('seq_districts');
    END IF;

    RETURN NEW;
END;
$$;

alter function fn_districts_bi() owner to postgres;

