create view vw_people(familia, name, otchestvo) as
SELECT o.familia,
       o.name,
       o.otchestvo
FROM owners o
UNION
SELECT d.familia,
       d.name,
       d.otchestvo
FROM director d
ORDER BY 1;

alter table vw_people
    owner to postgres;

