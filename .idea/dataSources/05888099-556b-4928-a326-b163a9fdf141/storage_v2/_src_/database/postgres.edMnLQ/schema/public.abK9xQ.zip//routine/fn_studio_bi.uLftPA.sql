create function fn_studio_bi() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.StudioID IS NULL THEN
        NEW.StudioID := nextval('seq_studio');
    END IF;

    RETURN NEW;
END;
$$;

alter function fn_studio_bi() owner to postgres;

