create view vw_films_above_average(caption) as
SELECT f.caption
FROM film f
         LEFT JOIN cassette c ON f.filmid = c.filmid
GROUP BY f.filmid, f.caption
HAVING count(*)::numeric > ((SELECT avg(t.cnt) AS avg
                             FROM (SELECT count(*) AS cnt
                                   FROM cassette
                                   GROUP BY cassette.filmid) t));

alter table vw_films_above_average
    owner to postgres;

