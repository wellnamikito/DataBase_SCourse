create view vw_unused_cassettes(casseteid, filmid, videoid, qualityid, photo, demand) as
SELECT casseteid,
       filmid,
       videoid,
       qualityid,
       photo,
       demand
FROM cassette
WHERE NOT (casseteid IN (SELECT cassette.casseteid
                         FROM receipt
                         WHERE cassette.casseteid IS NOT NULL));

alter table vw_unused_cassettes
    owner to postgres;

