create function fn_cassette_bi() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.CasseteID IS NULL THEN
        NEW.CasseteID := nextval('seq_cassette');
    END IF;

    RETURN NEW;
END;
$$;

alter function fn_cassette_bi() owner to postgres;

