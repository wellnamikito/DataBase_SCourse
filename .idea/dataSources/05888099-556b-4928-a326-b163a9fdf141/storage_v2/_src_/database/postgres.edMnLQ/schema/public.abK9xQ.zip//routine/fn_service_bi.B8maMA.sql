create function fn_service_bi() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.ServiceID IS NULL THEN
        NEW.ServiceID := nextval('seq_service');
    END IF;

    RETURN NEW;
END;
$$;

alter function fn_service_bi() owner to postgres;

