create function get_videos_by_mask(p_mask text)
    returns TABLE(video_caption character varying)
    language plpgsql
as
$$
BEGIN

    RETURN QUERY

        SELECT
            V.Caption

        FROM Video V

        WHERE V.Caption LIKE p_mask;

END;
$$;

alter function get_videos_by_mask(text) owner to postgres;

