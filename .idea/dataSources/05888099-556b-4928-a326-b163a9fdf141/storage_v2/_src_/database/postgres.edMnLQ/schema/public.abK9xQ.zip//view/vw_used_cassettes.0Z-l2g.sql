create view vw_used_cassettes(casseteid, filmid, videoid, qualityid, photo, demand) as
SELECT casseteid,
       filmid,
       videoid,
       qualityid,
       photo,
       demand
FROM cassette c
WHERE (casseteid IN (SELECT DISTINCT r.cassetteid
                     FROM receipt r));

alter table vw_used_cassettes
    owner to postgres;

