create view vw_cassettes_full(casseteid, filmcaption, videocaption) as
SELECT c.casseteid,
       f.caption AS filmcaption,
       v.caption AS videocaption
FROM cassette c
         JOIN film f ON f.filmid = c.filmid
         JOIN video v ON v.videoid = c.videoid;

alter table vw_cassettes_full
    owner to postgres;

