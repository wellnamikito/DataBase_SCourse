create function fn_director_bi() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.DirectorID IS NULL THEN
        NEW.DirectorID := nextval('seq_director');
    END IF;

    RETURN NEW;
END;
$$;

alter function fn_director_bi() owner to postgres;

