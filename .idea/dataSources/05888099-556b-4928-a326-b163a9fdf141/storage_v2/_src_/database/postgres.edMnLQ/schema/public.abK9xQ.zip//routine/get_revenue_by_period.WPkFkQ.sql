create function get_revenue_by_period(p_date_from date, p_date_to date)
    returns TABLE(video_caption character varying, total_revenue bigint)
    language plpgsql
as
$$
BEGIN

    RETURN QUERY

        SELECT
            V.Caption,
            COALESCE(SUM(R.Price),0)

        FROM Video V

                 LEFT JOIN Receipt R
                           ON R.VideoID = V.VideoID
                               AND R.Date BETWEEN p_date_from AND p_date_to

        GROUP BY V.VideoID, V.Caption;

END;
$$;

alter function get_revenue_by_period(date, date) owner to postgres;

