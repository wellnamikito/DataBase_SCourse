create function get_receipts_by_service_period(p_service_name text, p_date_from date, p_date_to date)
    returns TABLE(receipt_date date, receipt_price integer, service_name character varying)
    language plpgsql
as
$$
BEGIN

    RETURN QUERY

        SELECT
            R.Date,
            R.Price,
            S.ServiceName

        FROM Receipt R

                 INNER JOIN Service S
                            ON S.ServiceID = R.ServiceID

        WHERE S.ServiceName = p_service_name
          AND R.Date BETWEEN p_date_from AND p_date_to;

END;
$$;

alter function get_receipts_by_service_period(text, date, date) owner to postgres;

