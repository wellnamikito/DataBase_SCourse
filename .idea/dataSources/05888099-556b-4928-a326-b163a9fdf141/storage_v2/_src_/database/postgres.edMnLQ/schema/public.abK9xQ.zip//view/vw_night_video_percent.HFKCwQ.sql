create view vw_night_video_percent(districtname, night_percent) as
SELECT d.districtname,
       round(count(
                     CASE
                         WHEN v.timestart >= 22 OR v.timeend <= 6 THEN 1
                         ELSE NULL::integer
                         END)::numeric * 100.0 / count(*)::numeric) AS night_percent
FROM video v
         JOIN districts d ON d.districtid = v.districtid
GROUP BY d.districtname;

alter table vw_night_video_percent
    owner to postgres;

