create view vw_films_full(caption, familia, name, otchestvo, studioname) as
SELECT f.caption,
       d.familia,
       d.name,
       d.otchestvo,
       s.studioname
FROM film f
         JOIN director d ON f.directorid = d.directorid
         JOIN studio s ON s.studioid = f.studioid;

alter table vw_films_full
    owner to postgres;

