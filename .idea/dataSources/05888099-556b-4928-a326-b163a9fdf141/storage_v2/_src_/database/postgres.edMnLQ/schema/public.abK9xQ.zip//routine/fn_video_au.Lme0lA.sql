create function fn_video_au() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO AuditLog(TableName, OperationType)
    VALUES ('Video', 'UPDATE');

    RETURN NEW;
END;
$$;

alter function fn_video_au() owner to postgres;

