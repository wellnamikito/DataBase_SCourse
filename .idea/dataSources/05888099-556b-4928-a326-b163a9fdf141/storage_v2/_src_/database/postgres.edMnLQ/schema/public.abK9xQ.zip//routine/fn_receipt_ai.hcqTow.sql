create function fn_receipt_ai() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO AuditLog(TableName, OperationType)
    VALUES ('Receipt', 'INSERT');

    RETURN NEW;
END;
$$;

alter function fn_receipt_ai() owner to postgres;

