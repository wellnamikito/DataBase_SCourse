create view vw_receipts_full(receiptid, servicename, caption, date) as
SELECT r.receiptid,
       s.servicename,
       v.caption,
       r.date
FROM receipt r
         JOIN video v ON v.videoid = r.videoid
         JOIN service s ON s.serviceid = r.serviceid;

alter table vw_receipts_full
    owner to postgres;

