create view vw_video_simple(videoid, caption, address) as
SELECT videoid,
       caption,
       address
FROM video v;

alter table vw_video_simple
    owner to postgres;

