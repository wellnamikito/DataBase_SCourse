create view vw_receipt_category(receiptid, price_category) as
SELECT receiptid,
       CASE
           WHEN price <= 100 THEN 'дешево'::text
           WHEN price <= 500 THEN 'средне'::text
           ELSE 'дорого'::text
           END AS price_category
FROM (SELECT r.receiptid,
             r.price
      FROM receipt r
      WHERE r.price IS NOT NULL) t;

alter table vw_receipt_category
    owner to postgres;

