create function fn_video_bi() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.VideoID IS NULL THEN
        NEW.VideoID := nextval('seq_video');
    END IF;

    RETURN NEW;
END;
$$;

alter function fn_video_bi() owner to postgres;

