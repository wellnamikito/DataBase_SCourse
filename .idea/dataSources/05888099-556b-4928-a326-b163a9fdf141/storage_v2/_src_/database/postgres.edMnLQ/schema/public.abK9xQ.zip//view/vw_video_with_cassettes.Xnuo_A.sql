create view vw_video_with_cassettes(caption, casseteid) as
SELECT v.caption,
       c.casseteid
FROM video v
         LEFT JOIN cassette c ON v.videoid = c.videoid;

alter table vw_video_with_cassettes
    owner to postgres;

