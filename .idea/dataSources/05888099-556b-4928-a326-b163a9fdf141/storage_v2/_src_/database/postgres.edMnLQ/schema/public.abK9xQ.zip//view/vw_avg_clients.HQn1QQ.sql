create view vw_avg_clients(district, video, avg_clients) as
WITH video_clients AS (SELECT v.videoid,
                              v.caption,
                              v.districtid,
                              count(*) AS client_count
                       FROM receipt r
                                JOIN video v ON v.videoid = r.videoid
                       GROUP BY v.videoid, v.caption, v.districtid)
SELECT CASE
           WHEN GROUPING(d.districtname) = 1 THEN 'ГОРОД'::character varying
           ELSE d.districtname
           END                     AS district,
       CASE
           WHEN GROUPING(vc.caption) = 1 THEN 'ВСЕ ВИДЕОТЕКИ'::character varying
           ELSE vc.caption
           END                     AS video,
       round(avg(vc.client_count)) AS avg_clients
FROM video_clients vc
         JOIN districts d ON d.districtid = vc.districtid
GROUP BY ROLLUP (d.districtname, vc.caption);

alter table vw_avg_clients
    owner to postgres;

