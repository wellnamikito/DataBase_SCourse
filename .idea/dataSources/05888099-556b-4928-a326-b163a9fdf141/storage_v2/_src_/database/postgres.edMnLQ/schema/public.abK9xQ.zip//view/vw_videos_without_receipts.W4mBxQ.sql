create view vw_videos_without_receipts(caption) as
SELECT caption
FROM video v
WHERE NOT (EXISTS (SELECT 1
                   FROM receipt r
                   WHERE r.videoid = v.videoid));

alter table vw_videos_without_receipts
    owner to postgres;

