create view vw_best_worst_videos(caption, totalrevenue, category) as
(SELECT v.caption,
        sum(r.price)   AS totalrevenue,
        'Лучшие'::text AS category
 FROM video v
          LEFT JOIN receipt r ON v.videoid = r.videoid
 GROUP BY v.videoid, v.caption
 ORDER BY (sum(r.price)) DESC
 LIMIT 3)
UNION
(SELECT v.caption,
        sum(r.price)   AS totalrevenue,
        'Худшие'::text AS category
 FROM video v
          LEFT JOIN receipt r ON v.videoid = r.videoid
 GROUP BY v.videoid, v.caption
 ORDER BY (sum(r.price))
 LIMIT 3);

alter table vw_best_worst_videos
    owner to postgres;

