create function get_cassettes_by_quality(p_quality_name text)
    returns TABLE(film_caption character varying, quality_name character varying)
    language plpgsql
as
$$
BEGIN

    RETURN QUERY

        SELECT
            F.Caption,
            Q.QualityName

        FROM Cassette C

                 INNER JOIN Film F
                            ON F.FilmID = C.FilmID

                 INNER JOIN Quality Q
                            ON Q.QualityID = C.QualityID

        WHERE Q.QualityName = p_quality_name;

END;
$$;

alter function get_cassettes_by_quality(text) owner to postgres;

