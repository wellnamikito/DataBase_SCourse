create view vw_total_revenue(caption, total_amount, rent_revenue) as
SELECT v.caption,
       sum(COALESCE(r.price, 0)) AS total_amount,
       sum(
               CASE
                   WHEN s.servicename::text = 'Аренда'::text THEN r.price
                   ELSE 0
                   END)          AS rent_revenue
FROM receipt r
         LEFT JOIN video v ON v.videoid = r.videoid
         LEFT JOIN service s ON r.serviceid = s.serviceid
GROUP BY v.videoid, v.caption;

alter table vw_total_revenue
    owner to postgres;

