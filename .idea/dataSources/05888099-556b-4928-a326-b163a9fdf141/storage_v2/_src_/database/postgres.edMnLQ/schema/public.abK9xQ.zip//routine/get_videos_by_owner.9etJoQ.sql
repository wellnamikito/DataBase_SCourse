create function get_videos_by_owner(p_familia text)
    returns TABLE(video_caption character varying, video_address character varying, owner_familia character varying, owner_name character varying, owner_otchestvo character varying)
    language plpgsql
as
$$
BEGIN

    RETURN QUERY

        SELECT
            V.Caption,
            V.Address,
            O.Familia,
            O.Name,
            O.Otchestvo

        FROM Video V

                 INNER JOIN Owners O
                            ON O.OwnerID = V.OwnerID

        WHERE O.Familia = p_familia;

END;
$$;

alter function get_videos_by_owner(text) owner to postgres;

