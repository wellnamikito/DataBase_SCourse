create function fn_receipt_bu() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.Price <= 0 THEN
        RAISE EXCEPTION 'Цена должна быть больше 0';
    END IF;

    RETURN NEW;
END;
$$;

alter function fn_receipt_bu() owner to postgres;

