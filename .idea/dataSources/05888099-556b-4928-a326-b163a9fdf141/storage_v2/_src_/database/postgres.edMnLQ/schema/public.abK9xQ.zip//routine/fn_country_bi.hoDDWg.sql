create function fn_country_bi() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.CountryID IS NULL THEN
        NEW.CountryID := nextval('seq_country');
    END IF;

    RETURN NEW;
END;
$$;

alter function fn_country_bi() owner to postgres;

