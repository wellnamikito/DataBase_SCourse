create function get_service_stats(service_name text, year integer)
    returns TABLE(service text, clients_cnt integer, total_spent integer)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        S.ServiceName,
        COUNT(*),
        SUM(R.Price)
    FROM Receipt R
    LEFT JOIN Service S on R.ServiceID = S.ServiceID
    WHERE S.ServiceName = Service_name
        AND EXTRACT(YEAR FROM R.DATE) = year
    GROUP BY S.ServiceName;
END;
$$;

alter function get_service_stats(text, integer) owner to postgres;

