create function get_service_stats(service_name text, year integer)
    returns TABLE(service text, clients_cnt bigint, total_spent bigint)
    language plpgsql
as
$$
BEGIN

    RETURN QUERY

        SELECT
            S.ServiceName::TEXT,
            COUNT(*),
            SUM(R.Price)::BIGINT

        FROM Receipt R

                 LEFT JOIN Service S
                           ON R.ServiceID = S.ServiceID

        WHERE S.ServiceName = service_name
          AND EXTRACT(YEAR FROM R.Date) = year

        GROUP BY S.ServiceName;

END;
$$;

alter function get_service_stats(text, integer) owner to postgres;

