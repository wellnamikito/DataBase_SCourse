create function trg_vw_video_edit() returns trigger
    language plpgsql
as
$$
BEGIN

    UPDATE public.Video
    SET
        Caption = NEW.Caption,
        Address = NEW.Address
    WHERE VideoID = OLD.VideoID;

    RETURN NEW;

END;
$$;

alter function trg_vw_video_edit() owner to postgres;

