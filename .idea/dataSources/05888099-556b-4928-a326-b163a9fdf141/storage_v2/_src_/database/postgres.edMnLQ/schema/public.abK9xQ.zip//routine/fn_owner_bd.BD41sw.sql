create function fn_owner_bd() returns trigger
    language plpgsql
as
$$
BEGIN
    IF EXISTS (
        SELECT 1
        FROM Video
        WHERE OwnerId = OLD.OwnerID
    ) THEN
        RAISE EXCEPTION 'Нельзя удалить владельца';
    END IF;

    RETURN OLD;
END;
$$;

alter function fn_owner_bd() owner to postgres;

