create function update_video_view() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE Video
    SET Caption = NEW.Caption,
        Address = New.Address
    WHERE VideoID = OLD.VideoID;

    RETURN NEW;
end;
$$;

alter function update_video_view() owner to postgres;

