create function fn_film_bi() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.FilmID IS NULL THEN
        NEW.FilmID := nextval('seq_film');
    END IF;

    RETURN NEW;
END;
$$;

alter function fn_film_bi() owner to postgres;

