create function fn_receipt_ad() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO AuditLog(TableName, OperationType)
    VALUES ('Receipt', 'DELETE');

    RETURN OLD;
END;
$$;

alter function fn_receipt_ad() owner to postgres;

