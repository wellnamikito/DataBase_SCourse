create function fn_quality_bi() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.QualityID IS NULL THEN
        NEW.QualityID := nextval('seq_quality');
    END IF;

    RETURN NEW;
END;
$$;

alter function fn_quality_bi() owner to postgres;

