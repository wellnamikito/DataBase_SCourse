create function fn_owners_bi() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.OwnerID IS NULL THEN
        NEW.OwnerID := nextval('seq_owners');
    END IF;

    RETURN NEW;
END;
$$;

alter function fn_owners_bi() owner to postgres;

