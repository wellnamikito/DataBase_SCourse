create function get_operations_from_date(p_service_name text, p_date date)
    returns TABLE(receipt_date date, receipt_price integer, service_name character varying)
    language plpgsql
as
$$
BEGIN

    RETURN QUERY

        SELECT
            R.Date,
            R.Price,
            S.ServiceName

        FROM Receipt R

                 INNER JOIN Service S
                            ON S.ServiceID = R.ServiceID

        WHERE S.ServiceName = p_service_name
          AND R.Date >= p_date;

END;
$$;

alter function get_operations_from_date(text, date) owner to postgres;

