create view vw_video_edit(videoid, caption, address) as
SELECT videoid,
       caption,
       address
FROM video;

alter table vw_video_edit
    owner to postgres;

