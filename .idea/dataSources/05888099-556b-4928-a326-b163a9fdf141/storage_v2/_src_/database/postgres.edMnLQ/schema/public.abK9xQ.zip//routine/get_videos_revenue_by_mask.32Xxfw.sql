create function get_videos_revenue_by_mask(p_mask text)
    returns TABLE(video_caption character varying, total_revenue numeric)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT
            V.Caption,
            COALESCE(SUM(R.Price), 0)::NUMERIC AS total_revenue
        FROM Video V
                 LEFT JOIN Receipt R ON V.VideoID = R.VideoID
        WHERE V.Caption ILIKE '%' || p_mask || '%'
        GROUP BY V.VideoID, V.Caption;
END;
$$;

alter function get_videos_revenue_by_mask(text) owner to postgres;

